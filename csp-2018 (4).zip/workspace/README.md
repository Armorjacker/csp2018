<a target="_blank" href="https://scratch.mit.edu">  
  
  
  <!doctype html>
    <html lang="en">  
   <head>    
    <meta charset="utf-8">   
    <title>Portfolio</title>  
   </head>  
    
    
   <body>    
    <a href="index.html">Home</a>    
    <a href="portfolio.html">Portfolio</a>    
    <h1>This is my Portfolio Page!</h1>    
    <img src="images/portfolio.jpg" height="250">   
    <br>    
    <a target="_blank" href="https://scratch.mit.edu">      
    <img src="images/scratchlogo.png" height="100">    
    <img src="images/Coding.jpg" height="100">
    <img src="images/steak.jpg" height = "100">
      
    </a>  
 </body>
</html>








<!doctype html>
<html lang="en"> 
    <head>   
        <meta charset="utf-8">    
        <title>About Me!</title>  
    </head> 
    <body>   
        <a href="index.html">Home</a>   
        <a href="portfolio.html">Portfolio</a>  
        <a href="Aboutme.html">About me</a> 
        <img src="images/home.jpg" height="250"> 
        <img src="images/Coding.jpg" height="100">
         
  </body>
</html>


<!doctype html>
<html lang="en"> 
    <head>   
        <meta charset="utf-8">    
        <title>Portfolio</title>  
    </head> 
    <body>   
        <a href="index.html">Home</a>   
        <a href="portfolio.html">Portfolio</a>   
        <h1>This is my Portfolio</h1>   
        <img src="images/Lich_King_Glowei.jpg" height="250"> 
        <img src="images/home.jpg" height="250"> 
         
  </body>
</html>



<!doctype html>
<html lang="en"> 
    <head>   
        <meta charset="utf-8">    
        <title>Home</title>  
    </head> 
    <body>   
        <a href="index.html">Home</a>   
        <a href="portfolio.html">Portfolio</a>   
        <h1>This is Elijiah's Home Page!</h1>   
        <img src="images/home.jpg" height="250"> 
        <img src="images/Coding.jpg" height="100">
         
  </body>
</html>








<!DOCTYPE html>
<!-- HTML5 Hello world by kirupa - http://www.kirupa.com/html5/getting_your_feet_wet_html5_pg1.htm -->
<html lang="en-us">

<head>
<meta charset="utf-8">
<title>Hello...</title>
<style type="text/css">
#mainContent {
	font-family: Arial, Helvetica, sans-serif;
	font-size: xx-large;
	font-weight: bold;
	background-color: #E3F0FB;
	border-radius: 4px;
	padding: 10px;
	text-align: center;
}
.buttonStyle {
	border-radius: 4px;
	border: thin solid #F0E020;
	padding: 5px;
	background-color: #F8F094;
	font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
	font-weight: bold;
	color: #663300;
	width: 75px;
}

.buttonStyle:hover {
	border: thin solid #FFCC00;
	background-color: #FCF9D6;
	color: #996633;
	cursor: pointer;
}
.buttonStyle:active {
	border: thin solid #99CC00;
	background-color: #F5FFD2;
	color: #669900;
	cursor: pointer;
}

</style>
</head>

<body>
<div id="mainContent">
<p id="helloText">?</p>
<button id="clickButton" class="buttonStyle">click me</button>
</div>
<script> 
var myButton = document.getElementById("clickButton");
var myText = document.getElementById("helloText");

myButton.addEventListener('click', doSomething, false)

function doSomething() {
	myText.textContent = "hello, world!";
}
</script>

</body>
</html>
